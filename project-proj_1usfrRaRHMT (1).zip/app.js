function App() {
    try {
        const [user, setUser] = React.useState(null);
        const [currentPage, setCurrentPage] = React.useState('home');

        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        const handleLogin = (userData) => {
            setUser(userData);
            trackUserActivity(userData.objectId, 'Connexion');
            if (userData.objectData.role === 'admin') {
                setCurrentPage('admin');
            } else {
                setCurrentPage('dashboard');
            }
        };

        const handleRegister = (userData) => {
            setUser(userData);
            setCurrentPage('dashboard');
            trackUserActivity(userData.objectId, 'Inscription');
        };

        const handleLogout = () => {
            if (user) {
                trackUserActivity(user.objectId, 'Déconnexion');
            }
            setUser(null);
            setCurrentPage('home');
        };

        const renderPage = () => {
            switch (currentPage) {
                case 'home':
                    return <HomePage />;
                case 'dashboard':
                    return user ? <Dashboard user={user} /> : <HomePage />;
                case 'admin':
                    return user && user.objectData.role === 'admin' ? 
                        <AdminDashboard user={user} /> : <HomePage />;
                case 'prediction':
                    return user ? <PredictionPage user={user} /> : <HomePage />;
                default:
                    return <HomePage />;
            }
        };

        return (
            <div data-name="App" data-file="app.js">
                <div className="min-h-screen bg-gray-50">
                    <Header 
                        user={user} 
                        onLogin={handleLogin}
                        onRegister={handleRegister}
                        onLogout={handleLogout}
                    />
                    
                    <nav className="bg-white shadow-sm border-t">
                        <div className="container mx-auto px-4">
                            <div className="flex space-x-6 py-3">
                                <button 
                                    onClick={() => setCurrentPage('home')}
                                    className="text-gray-600 hover:text-blue-600 transition-colors"
                                >
                                    Accueil
                                </button>
                                {user && (
                                    <button 
                                        onClick={() => setCurrentPage('dashboard')}
                                        className="text-gray-600 hover:text-blue-600 transition-colors"
                                    >
                                        Tableau de bord
                                    </button>
                                )}
                                {user && (
                                    <button 
                                        onClick={() => setCurrentPage('prediction')}
                                        className="text-gray-600 hover:text-blue-600 transition-colors"
                                    >
                                        Diagnostic
                                    </button>
                                )}
                                {user && user.objectData.role === 'admin' && (
                                    <button 
                                        onClick={() => setCurrentPage('admin')}
                                        className="text-gray-600 hover:text-blue-600 transition-colors"
                                    >
                                        Admin
                                    </button>
                                )}
                            </div>
                        </div>
                    </nav>

                    <main>
                        {renderPage()}
                    </main>

                    <Footer />
                </div>
            </div>
        );
    } catch (error) {
        console.error('App component error:', error);
        reportError(error);
    }
}

ReactDOM.render(<App />, document.getElementById('root'));
