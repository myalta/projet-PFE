function Footer() {
    try {
        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        return (
            <div data-name="Footer" data-file="components/Footer.js">
                <footer className="bg-gray-800 text-white py-8">
                    <div className="container mx-auto px-4">
                        <div className="grid md:grid-cols-3 gap-8">
                            <div>
                                <h3 className="text-xl font-bold mb-4">Projet de fin d'étude ENASTIC</h3>
                                <p className="text-gray-300">
                                    Plateforme de prédiction des maladies conçue dans le cadre d'un projet 
                                    de fin d'études cycle licence à l'ENASTIC.
                                </p>
                            </div>
                            
                            <div>
                                <h4 className="text-lg font-semibold mb-4">Liens rapides</h4>
                                <ul className="space-y-2">
                                    <li><a href="#home" className="text-gray-300 hover:text-white transition-colors">Accueil</a></li>
                                    <li><a href="#about" className="text-gray-300 hover:text-white transition-colors">À propos</a></li>
                                    <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
                                    <li><a href="#prediction" className="text-gray-300 hover:text-white transition-colors">Diagnostic</a></li>
                                </ul>
                            </div>
                            
                            <div>
                                <h4 className="text-lg font-semibold mb-4">Suivez-nous</h4>
                                <div className="flex space-x-4">
                                    <a href="#" className="social-icon text-gray-300 hover:text-blue-400">
                                        <i data-lucide="facebook" className="w-6 h-6"></i>
                                    </a>
                                    <a href="#" className="social-icon text-gray-300 hover:text-blue-400">
                                        <i data-lucide="twitter" className="w-6 h-6"></i>
                                    </a>
                                    <a href="#" className="social-icon text-gray-300 hover:text-green-400">
                                        <i data-lucide="message-circle" className="w-6 h-6"></i>
                                    </a>
                                    <a href="#" className="social-icon text-gray-300 hover:text-purple-400">
                                        <i data-lucide="instagram" className="w-6 h-6"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
                            <div className="flex items-center space-x-4 mb-4 md:mb-0">
                                <img 
                                    src="https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?w=80&h=80&fit=crop&crop=center" 
                                    alt="ENASTIC Logo" 
                                    className="w-12 h-12 rounded-full"
                                />
                                <span className="text-sm text-gray-300">École Nationale des Sciences et Techniques Informatiques</span>
                            </div>
                            <div className="text-center">
                                <p className="text-sm text-gray-300">© 2024 MYALTA BIEN-AIMÉ - Tous droits réservés</p>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        );
    } catch (error) {
        console.error('Footer component error:', error);
        reportError(error);
    }
}
