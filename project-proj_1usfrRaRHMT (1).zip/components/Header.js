function Header({ user, onLogin, onRegister, onLogout }) {
    try {
        const [showLoginModal, setShowLoginModal] = React.useState(false);
        const [showRegisterModal, setShowRegisterModal] = React.useState(false);

        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        return (
            <div data-name="Header" data-file="components/Header.js">
                <header className="bg-white shadow-lg">
                    <div className="container mx-auto px-4 py-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                                <i data-lucide="activity" className="w-8 h-8 text-blue-600"></i>
                                <h1 className="text-2xl font-bold text-gray-800">Projet de fin d'étude ENASTIC</h1>
                            </div>
                            
                            <nav className="hidden md:flex items-center space-x-6">
                                <a href="#home" className="text-gray-600 hover:text-blue-600 transition-colors">Accueil</a>
                                <a href="#about" className="text-gray-600 hover:text-blue-600 transition-colors">À propos</a>
                                <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">Contact</a>
                                {user && (
                                    <a href="#prediction" className="text-gray-600 hover:text-blue-600 transition-colors">Diagnostic</a>
                                )}
                            </nav>

                            <div className="flex items-center space-x-3">
                                {user ? (
                                    <div className="flex items-center space-x-3">
                                        <span className="text-gray-700">Bonjour, {user.objectData.nom}</span>
                                        <button 
                                            onClick={onLogout}
                                            className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
                                        >
                                            Déconnexion
                                        </button>
                                    </div>
                                ) : (
                                    <div className="flex space-x-2">
                                        <button 
                                            onClick={() => setShowLoginModal(true)}
                                            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                                        >
                                            Connexion
                                        </button>
                                        <button 
                                            onClick={() => setShowRegisterModal(true)}
                                            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
                                        >
                                            Inscription
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </header>

                {showLoginModal && (
                    <LoginModal 
                        onClose={() => setShowLoginModal(false)}
                        onLogin={onLogin}
                    />
                )}

                {showRegisterModal && (
                    <RegisterModal 
                        onClose={() => setShowRegisterModal(false)}
                        onRegister={onRegister}
                    />
                )}
            </div>
        );
    } catch (error) {
        console.error('Header component error:', error);
        reportError(error);
    }
}
