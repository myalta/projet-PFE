function HomePage() {
    try {
        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        return (
            <div data-name="HomePage" data-file="pages/HomePage.js">
                <div className="bg-gradient-health text-white py-16">
                    <div className="container mx-auto px-4 text-center">
                        <h1 className="text-4xl md:text-6xl font-bold mb-6">
                            Bienvenue sur la Plateforme de Prédiction
                        </h1>
                        <p className="text-xl md:text-2xl mb-8 opacity-90">
                            Conçue dans le cadre d'un projet de fin d'études cycle licence à l'ENASTIC
                        </p>
                        <p className="text-lg mb-8 max-w-3xl mx-auto">
                            Notre plateforme utilise l'intelligence artificielle et le machine learning 
                            pour la détection précoce du diabète, offrant des conseils personnalisés 
                            et un suivi médical avancé.
                        </p>
                    </div>
                </div>

                <div className="py-16 bg-gray-50">
                    <div className="container mx-auto px-4">
                        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">
                            Comprendre le Diabète
                        </h2>
                        
                        <div className="grid md:grid-cols-3 gap-8 mb-16">
                            <div className="bg-white rounded-lg shadow-lg p-6 card-hover">
                                <div className="text-center mb-4">
                                    <i data-lucide="alert-triangle" className="w-12 h-12 text-red-500 mx-auto mb-4"></i>
                                    <h3 className="text-xl font-bold text-gray-800">Causes</h3>
                                </div>
                                <ul className="text-gray-600 space-y-2">
                                    <li>• Prédisposition génétique</li>
                                    <li>• Mode de vie sédentaire</li>
                                    <li>• Alimentation déséquilibrée</li>
                                    <li>• Surpoids et obésité</li>
                                    <li>• Stress chronique</li>
                                </ul>
                            </div>

                            <div className="bg-white rounded-lg shadow-lg p-6 card-hover">
                                <div className="text-center mb-4">
                                    <i data-lucide="eye" className="w-12 h-12 text-orange-500 mx-auto mb-4"></i>
                                    <h3 className="text-xl font-bold text-gray-800">Symptômes</h3>
                                </div>
                                <ul className="text-gray-600 space-y-2">
                                    <li>• Soif excessive</li>
                                    <li>• Urination fréquente</li>
                                    <li>• Fatigue persistante</li>
                                    <li>• Vision floue</li>
                                    <li>• Perte de poids inexpliquée</li>
                                </ul>
                            </div>

                            <div className="bg-white rounded-lg shadow-lg p-6 card-hover">
                                <div className="text-center mb-4">
                                    <i data-lucide="heart" className="w-12 h-12 text-purple-500 mx-auto mb-4"></i>
                                    <h3 className="text-xl font-bold text-gray-800">Conséquences</h3>
                                </div>
                                <ul className="text-gray-600 space-y-2">
                                    <li>• Maladies cardiovasculaires</li>
                                    <li>• Problèmes rénaux</li>
                                    <li>• Complications oculaires</li>
                                    <li>• Neuropathie diabétique</li>
                                    <li>• Problèmes de cicatrisation</li>
                                </ul>
                            </div>
                        </div>

                        <div className="bg-blue-50 rounded-lg p-8 text-center">
                            <h3 className="text-2xl font-bold text-blue-800 mb-4">
                                L'importance de la détection précoce
                            </h3>
                            <p className="text-blue-700 text-lg mb-6">
                                La détection précoce du diabète permet une prise en charge rapide, 
                                réduisant significativement les risques de complications graves. 
                                Notre IA analyse vos données pour identifier les signes avant-coureurs.
                            </p>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="bg-white rounded-lg p-4">
                                    <i data-lucide="shield-check" className="w-8 h-8 text-green-500 mx-auto mb-2"></i>
                                    <h4 className="font-semibold text-gray-800">Prévention efficace</h4>
                                    <p className="text-gray-600 text-sm">Agir avant l'apparition des symptômes</p>
                                </div>
                                <div className="bg-white rounded-lg p-4">
                                    <i data-lucide="trending-up" className="w-8 h-8 text-blue-500 mx-auto mb-2"></i>
                                    <h4 className="font-semibold text-gray-800">Meilleur pronostic</h4>
                                    <p className="text-gray-600 text-sm">Traitement plus efficace et moins invasif</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('HomePage component error:', error);
        reportError(error);
    }
}
