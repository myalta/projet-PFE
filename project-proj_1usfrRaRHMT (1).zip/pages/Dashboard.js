function Dashboard({ user }) {
    try {
        const [predictions, setPredictions] = React.useState([]);
        const [stats, setStats] = React.useState({
            totalPredictions: 0,
            riskLevel: 'Faible',
            lastVisit: new Date().toLocaleDateString()
        });

        React.useEffect(() => {
            lucide.createIcons();
            loadUserPredictions();
        }, []);

        const loadUserPredictions = async () => {
            try {
                const userPredictions = await trickleListObjects(`prediction:${user.objectId}`, 10, true);
                setPredictions(userPredictions.items);
                setStats({
                    totalPredictions: userPredictions.items.length,
                    riskLevel: userPredictions.items.length > 0 ? userPredictions.items[0].objectData.risk : 'Aucune',
                    lastVisit: new Date().toLocaleDateString()
                });
            } catch (error) {
                console.error('Erreur chargement prédictions:', error);
            }
        };

        return (
            <div data-name="Dashboard" data-file="pages/Dashboard.js">
                <div className="container mx-auto px-4 py-8">
                    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
                        <div className="flex items-center space-x-4 mb-6">
                            <img 
                                src={user.objectData.photo || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'} 
                                alt="Profile" 
                                className="w-16 h-16 rounded-full object-cover"
                            />
                            <div>
                                <h1 className="text-2xl font-bold text-gray-800">
                                    {user.objectData.prenom} {user.objectData.nom}
                                </h1>
                                <p className="text-gray-600">{user.objectData.email}</p>
                            </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-6">
                            <div className="bg-blue-50 rounded-lg p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-sm text-blue-600">Prédictions totales</p>
                                        <p className="text-2xl font-bold text-blue-800">{stats.totalPredictions}</p>
                                    </div>
                                    <i data-lucide="activity" className="w-8 h-8 text-blue-500"></i>
                                </div>
                            </div>

                            <div className="bg-green-50 rounded-lg p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-sm text-green-600">Niveau de risque</p>
                                        <p className="text-2xl font-bold text-green-800">{stats.riskLevel}</p>
                                    </div>
                                    <i data-lucide="shield" className="w-8 h-8 text-green-500"></i>
                                </div>
                            </div>

                            <div className="bg-purple-50 rounded-lg p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-sm text-purple-600">Dernière visite</p>
                                        <p className="text-lg font-bold text-purple-800">{stats.lastVisit}</p>
                                    </div>
                                    <i data-lucide="calendar" className="w-8 h-8 text-purple-500"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-lg p-6">
                        <h2 className="text-xl font-bold text-gray-800 mb-4">Historique des prédictions</h2>
                        {predictions.length > 0 ? (
                            <div className="space-y-4">
                                {predictions.map((prediction, index) => (
                                    <div key={index} className="border rounded-lg p-4 bg-gray-50">
                                        <div className="flex justify-between items-center">
                                            <div>
                                                <p className="font-semibold">Prédiction #{index + 1}</p>
                                                <p className="text-sm text-gray-600">{prediction.createdAt}</p>
                                            </div>
                                            <span className={`px-3 py-1 rounded-full text-sm ${
                                                prediction.objectData.risk === 'Élevé' ? 'bg-red-100 text-red-800' :
                                                prediction.objectData.risk === 'Moyen' ? 'bg-yellow-100 text-yellow-800' :
                                                'bg-green-100 text-green-800'
                                            }`}>
                                                {prediction.objectData.risk}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-500 text-center py-8">Aucune prédiction effectuée</p>
                        )}
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('Dashboard component error:', error);
        reportError(error);
    }
}
