function AdminDashboard({ user }) {
    try {
        const [patients, setPatients] = React.useState([]);
        const [activities, setActivities] = React.useState([]);
        const [newAdmin, setNewAdmin] = React.useState({ nom: '', prenom: '', email: '', password: '' });

        React.useEffect(() => {
            lucide.createIcons();
            loadPatientsData();
        }, []);

        const loadPatientsData = async () => {
            try {
                const users = await trickleListObjects('user', 100, true);
                const patientsList = users.items.filter(u => u.objectData.role === 'patient');
                setPatients(patientsList);
                
                const activitiesData = [];
                for (const patient of patientsList.slice(0, 10)) {
                    const userActivities = await trickleListObjects(`activity:${patient.objectId}`, 5, true);
                    activitiesData.push(...userActivities.items.map(a => ({
                        ...a,
                        patientName: `${patient.objectData.prenom} ${patient.objectData.nom}`
                    })));
                }
                setActivities(activitiesData);
            } catch (error) {
                console.error('Erreur chargement données:', error);
            }
        };

        const handleCreateAdmin = async (e) => {
            e.preventDefault();
            try {
                await createAdmin(newAdmin);
                alert('Administrateur créé avec succès');
                setNewAdmin({ nom: '', prenom: '', email: '', password: '' });
            } catch (error) {
                alert('Erreur lors de la création');
            }
        };

        const printPatientInfo = (patient) => {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html><head><title>Informations Patient</title></head>
                <body>
                    <h2>Informations du Patient</h2>
                    <p><strong>Nom:</strong> ${patient.objectData.nom}</p>
                    <p><strong>Prénom:</strong> ${patient.objectData.prenom}</p>
                    <p><strong>Email:</strong> ${patient.objectData.email}</p>
                    <p><strong>Inscription:</strong> ${patient.createdAt}</p>
                    <p><strong>Dernière connexion:</strong> ${patient.objectData.lastLogin}</p>
                </body></html>
            `);
            printWindow.print();
        };

        return (
            <div data-name="AdminDashboard" data-file="pages/AdminDashboard.js">
                <div className="container mx-auto px-4 py-8">
                    <h1 className="text-3xl font-bold mb-8">Tableau de Bord Administrateur</h1>
                    
                    <div className="grid md:grid-cols-2 gap-8">
                        <div className="bg-white rounded-lg shadow-lg p-6">
                            <h2 className="text-xl font-bold mb-4">Liste des Patients</h2>
                            <div className="space-y-4 max-h-96 overflow-y-auto">
                                {patients.map((patient) => (
                                    <div key={patient.objectId} className="border rounded-lg p-4">
                                        <div className="flex justify-between items-center">
                                            <div>
                                                <p className="font-semibold">
                                                    {patient.objectData.prenom} {patient.objectData.nom}
                                                </p>
                                                <p className="text-sm text-gray-600">{patient.objectData.email}</p>
                                                <p className="text-xs text-gray-500">
                                                    Inscrit le: {new Date(patient.createdAt).toLocaleDateString()}
                                                </p>
                                            </div>
                                            <button
                                                onClick={() => printPatientInfo(patient)}
                                                className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                                            >
                                                Imprimer
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="bg-white rounded-lg shadow-lg p-6">
                            <h2 className="text-xl font-bold mb-4">Créer un Administrateur</h2>
                            <form onSubmit={handleCreateAdmin} className="space-y-4">
                                <input
                                    type="text"
                                    placeholder="Nom"
                                    required
                                    className="w-full px-3 py-2 border rounded-lg"
                                    value={newAdmin.nom}
                                    onChange={(e) => setNewAdmin({...newAdmin, nom: e.target.value})}
                                />
                                <input
                                    type="text"
                                    placeholder="Prénom"
                                    required
                                    className="w-full px-3 py-2 border rounded-lg"
                                    value={newAdmin.prenom}
                                    onChange={(e) => setNewAdmin({...newAdmin, prenom: e.target.value})}
                                />
                                <input
                                    type="email"
                                    placeholder="Email"
                                    required
                                    className="w-full px-3 py-2 border rounded-lg"
                                    value={newAdmin.email}
                                    onChange={(e) => setNewAdmin({...newAdmin, email: e.target.value})}
                                />
                                <input
                                    type="password"
                                    placeholder="Mot de passe"
                                    required
                                    className="w-full px-3 py-2 border rounded-lg"
                                    value={newAdmin.password}
                                    onChange={(e) => setNewAdmin({...newAdmin, password: e.target.value})}
                                />
                                <button
                                    type="submit"
                                    className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600"
                                >
                                    Créer Administrateur
                                </button>
                            </form>
                        </div>
                    </div>

                    <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
                        <h2 className="text-xl font-bold mb-4">Activité des Patients</h2>
                        <div className="space-y-3">
                            {activities.map((activity, index) => (
                                <div key={index} className="flex justify-between items-center border-b pb-2">
                                    <div>
                                        <p className="font-medium">{activity.patientName}</p>
                                        <p className="text-sm text-gray-600">{activity.objectData.activity}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-sm">{new Date(activity.objectData.timestamp).toLocaleString()}</p>
                                        <p className="text-xs text-gray-500">Durée: {activity.objectData.duration}s</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('AdminDashboard component error:', error);
        reportError(error);
    }
}
