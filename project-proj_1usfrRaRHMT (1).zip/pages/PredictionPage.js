function PredictionPage({ user }) {
    try {
        const [formData, setFormData] = React.useState({
            pregnancies: '',
            glucose: '',
            bloodPressure: '',
            skinThickness: '',
            insulin: '',
            bmi: '',
            diabetesPedigree: '',
            age: ''
        });
        const [result, setResult] = React.useState(null);
        const [loading, setLoading] = React.useState(false);

        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            
            try {
                const numericData = Object.fromEntries(
                    Object.entries(formData).map(([key, value]) => [key, parseFloat(value)])
                );
                
                const prediction = await predictDiabetes(numericData);
                await savePrediction(user.objectId, prediction, numericData);
                setResult(prediction);
            } catch (error) {
                alert('Erreur lors de la prédiction');
            } finally {
                setLoading(false);
            }
        };

        return (
            <div data-name="PredictionPage" data-file="pages/PredictionPage.js">
                <div className="container mx-auto px-4 py-8">
                    <h1 className="text-3xl font-bold text-center mb-8">Diagnostic du Diabète</h1>
                    
                    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1">Grossesses</label>
                                    <input
                                        type="number"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.pregnancies}
                                        onChange={(e) => setFormData({...formData, pregnancies: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">Glucose (mg/dL)</label>
                                    <input
                                        type="number"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.glucose}
                                        onChange={(e) => setFormData({...formData, glucose: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">Pression artérielle</label>
                                    <input
                                        type="number"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.bloodPressure}
                                        onChange={(e) => setFormData({...formData, bloodPressure: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">Épaisseur peau (mm)</label>
                                    <input
                                        type="number"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.skinThickness}
                                        onChange={(e) => setFormData({...formData, skinThickness: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">Insuline</label>
                                    <input
                                        type="number"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.insulin}
                                        onChange={(e) => setFormData({...formData, insulin: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">IMC</label>
                                    <input
                                        type="number"
                                        step="0.1"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.bmi}
                                        onChange={(e) => setFormData({...formData, bmi: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">Hérédité diabète</label>
                                    <input
                                        type="number"
                                        step="0.001"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.diabetesPedigree}
                                        onChange={(e) => setFormData({...formData, diabetesPedigree: e.target.value})}
                                    />
                                </div>
                                
                                <div>
                                    <label className="block text-sm font-medium mb-1">Âge</label>
                                    <input
                                        type="number"
                                        required
                                        className="w-full px-3 py-2 border rounded-lg"
                                        value={formData.age}
                                        onChange={(e) => setFormData({...formData, age: e.target.value})}
                                    />
                                </div>
                            </div>
                            
                            <button
                                type="submit"
                                disabled={loading}
                                className="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 disabled:opacity-50"
                            >
                                {loading ? 'Analyse en cours...' : 'Analyser'}
                            </button>
                        </form>

                        {result && (
                            <div className="mt-8 p-6 bg-gray-50 rounded-lg">
                                <h3 className="text-xl font-bold mb-4">Résultat de l'analyse</h3>
                                <div className="space-y-4">
                                    <div className={`p-4 rounded-lg ${
                                        result.risk === 'Élevé' ? 'bg-red-100' :
                                        result.risk === 'Moyen' ? 'bg-yellow-100' : 'bg-green-100'
                                    }`}>
                                        <p className="font-semibold">Niveau de risque: {result.risk}</p>
                                        <p>Probabilité: {result.probability}%</p>
                                    </div>
                                    
                                    <div>
                                        <h4 className="font-semibold mb-2">Recommandations:</h4>
                                        <ul className="space-y-1">
                                            {result.recommendations.map((rec, index) => (
                                                <li key={index} className="text-sm">• {rec}</li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('PredictionPage component error:', error);
        reportError(error);
    }
}
