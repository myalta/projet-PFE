const authenticateUser = async (email, password) => {
    try {
        const users = await trickleListObjects('user', 100, true);
        const user = users.items.find(u => 
            u.objectData.email === email && u.objectData.password === password
        );
        
        if (user) {
            await trickleUpdateObject('user', user.objectId, {
                ...user.objectData,
                lastLogin: new Date().toISOString(),
                sessionTime: Date.now()
            });
            return user;
        }
        return null;
    } catch (error) {
        console.error('Erreur authentification:', error);
        throw error;
    }
};

const registerUser = async (userData) => {
    try {
        const existingUsers = await trickleListObjects('user', 100, true);
        const emailExists = existingUsers.items.some(u => u.objectData.email === userData.email);
        
        if (emailExists) {
            throw new Error('Email déjà utilisé');
        }

        const newUser = await trickleCreateObject('user', {
            ...userData,
            role: 'patient',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            sessionTime: Date.now()
        });
        
        return newUser;
    } catch (error) {
        console.error('Erreur inscription:', error);
        throw error;
    }
};

const createAdmin = async (adminData) => {
    try {
        const newAdmin = await trickleCreateObject('user', {
            ...adminData,
            role: 'admin',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
        });
        return newAdmin;
    } catch (error) {
        console.error('Erreur création admin:', error);
        throw error;
    }
};

const trackUserActivity = async (userId, activity) => {
    try {
        await trickleCreateObject(`activity:${userId}`, {
            activity,
            timestamp: new Date().toISOString(),
            duration: Math.floor(Math.random() * 3600)
        });
    } catch (error) {
        console.error('Erreur tracking:', error);
    }
};
