const predictDiabetes = async (patientData) => {
    try {
        const {
            pregnancies,
            glucose,
            bloodPressure,
            skinThickness,
            insulin,
            bmi,
            diabetesPedigree,
            age
        } = patientData;

        let riskScore = 0;

        if (glucose > 140) riskScore += 30;
        else if (glucose > 100) riskScore += 15;

        if (bmi > 30) riskScore += 25;
        else if (bmi > 25) riskScore += 10;

        if (age > 45) riskScore += 20;
        else if (age > 30) riskScore += 10;

        if (bloodPressure > 140) riskScore += 15;
        if (pregnancies > 3) riskScore += 10;
        if (insulin > 200) riskScore += 10;
        if (diabetesPedigree > 0.5) riskScore += 15;

        let risk, probability;
        if (riskScore >= 70) {
            risk = 'Élevé';
            probability = 85 + Math.random() * 10;
        } else if (riskScore >= 40) {
            risk = 'Moyen';
            probability = 45 + Math.random() * 30;
        } else {
            risk = 'Faible';
            probability = 5 + Math.random() * 25;
        }

        const recommendations = generateRecommendations(risk, patientData);

        return {
            risk,
            probability: Math.round(probability),
            riskScore,
            recommendations,
            analysisDate: new Date().toISOString()
        };
    } catch (error) {
        console.error('Erreur prédiction:', error);
        throw error;
    }
};

const generateRecommendations = (risk, data) => {
    const recommendations = [];
    
    if (data.bmi > 25) {
        recommendations.push('Maintenir un poids santé par une alimentation équilibrée');
    }
    
    if (data.glucose > 100) {
        recommendations.push('Surveiller régulièrement la glycémie');
        recommendations.push('Réduire la consommation de sucres raffinés');
    }
    
    if (risk === 'Élevé') {
        recommendations.push('Consulter un médecin rapidement');
        recommendations.push('Effectuer des examens complémentaires');
    }
    
    recommendations.push('Pratiquer une activité physique régulière');
    recommendations.push('Adopter une alimentation riche en fibres');
    
    return recommendations;
};

const savePrediction = async (userId, predictionData, inputData) => {
    try {
        const prediction = await trickleCreateObject(`prediction:${userId}`, {
            ...predictionData,
            inputData,
            patientId: userId,
            createdAt: new Date().toISOString()
        });
        return prediction;
    } catch (error) {
        console.error('Erreur sauvegarde:', error);
        throw error;
    }
};
